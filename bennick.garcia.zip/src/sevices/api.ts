export const COUNTRY_SERVICE = " http://localhost:8888/countriesArray"

